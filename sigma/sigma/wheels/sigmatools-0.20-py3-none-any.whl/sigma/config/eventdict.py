event = {
    1: ('childproc_count','[1 to *]'),
    # 2: Change time,
    3: ('netconn_count','[1 to *]'),
    # 4: sysmon state change
    # 5: Process termincated
    6: ('modload_count','[1 to *]'),
    7: ('modload_count','[1 to *]'),
    8: ('crossproc_count', '[1 to *]'),
    # 9: Raw Access Read
    10: ('crossproc_count', '[1 to *]'),
    11: ('filemod_count','[1 to *]'),
    12: ('regmod_count','[1 to *]'),
    13: ('regmod_count','[1 to *]'),
    14: ('',''),
    15: ('',''),
    16: ('',''),
    17: ('',''),
    18: ('',''),
    19: ('',''),
    20: ('',''),
    21: ('',''),
    # 15 File create stream hash
}